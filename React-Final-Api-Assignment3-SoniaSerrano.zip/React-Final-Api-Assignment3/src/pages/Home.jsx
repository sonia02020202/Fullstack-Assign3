// pages/Home.jsx
export default function Home() {
    return (
      <div className="p-6">
        <h1 className="text-3xl font-bold mb-4">Welcome to Sonia's Portfolio Site</h1>
        <p>This is using React and Express full stack portfolio project with data loaded from MongoDB via an API.
           created by myself. 
        </p>
      </div>
    );
  }